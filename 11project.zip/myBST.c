#include "myBST.h"

TreeNode* create_tree_node(int key) {//function to craete a node
    TreeNode* node = (TreeNode*)malloc(sizeof(TreeNode));//allocating memory to the datastructure 
    node->key = key;
    node->left = NULL;
    node->right = NULL;
    node->parent = NULL;
    return node;
}

void insert(TreeNode *root, TreeNode *node) {
    TreeNode *current = root;//insilatizing the current and the parent node
    TreeNode *parent = NULL;

    while (current != NULL) {//travesing 
        parent = current;
        if (node->key < current->key) {//we know that if the data is less than the node value than the traveling must happen on the left sub tree
            current = current->left;
        } else { 
            current = current->right;//else if the data is not smaller(is greter) than travel in the right side 
        }
    }
    //inserting the node 
    node->parent = parent;
    if (node->key < parent->key) {
        parent->left = node;
    } else {
        parent->right = node;
    }
}

// search for a node 
TreeNode* find_key(TreeNode *root, int key) {
    TreeNode *current = root;
    while (current != NULL) {//traveling throught the tree
        if (key == current->key) {//if found 
            return current;
        } else if (key < current->key) {//if less than go to left
            current = current->left;
        } else {
            current = current->right;//if grater than go to right 
        }
    }
    return NULL; // return null if not found 
}

//minimum node 
TreeNode* find_min(TreeNode *node) {//we know that to find the min value in a bst we need to look at the leftmost element 
    while (node->left != NULL) {
        node = node->left;
    }
    return node;
}

//maximum node
TreeNode* find_max(TreeNode *node) {//we know that to find the largest/maximun element we need to look at the rightmost element 
    while (node->right != NULL) {
        node = node->right;
    }
    return node;
}

// successor
TreeNode* find_successor(TreeNode *node) {
    if (node->right != NULL) {//if the node has a right child than we search for the min elemnt in it
        return find_min(node->right);
    }
    //if the node doent have a right child than we look fir the successir in the parent/ancestor node 
    TreeNode *parent = node->parent;
    while (parent != NULL && node == parent->right) {
        node = parent;
        parent = parent->parent;
    }
    return parent;//return the value 
}

// predecessor
TreeNode* find_predecessor(TreeNode *node) {
    if (node->left != NULL) {//if the left child of the node exhist we search for the max of its left child
        return find_max(node->left);
    }
    TreeNode *parent = node->parent;
    //else we search for the predecessor in the parent node
    while (parent != NULL && node == parent->left) {
        node = parent;
        parent = parent->parent;
    }
    return parent;
}

//helper delete_helper for the delete function

void delete_helper(TreeNode **root, TreeNode *u, TreeNode *v) {
    if (u->parent == NULL) {
        *root = v;
    }
    else if (u == u->parent->left) {
        u->parent->left = v;
    }
    else {
        u->parent->right = v;
    }
    if (v != NULL) {
        v->parent = u->parent;
    }
}

// Delete a node from the BST and return the new root
TreeNode* delete_node(TreeNode *root, TreeNode *node) {
    if (node == NULL) return root;
    //cases where the node has only one child
    if (node->left == NULL) {//only right child exhist 
        delete_helper(&root, node, node->right);
    }
    else if (node->right == NULL) {//only left child exhist 
        delete_helper(&root, node, node->left);
    }
    //else case where both the children exhist...we find the inorder successor and than delete and transplat
    else {
        TreeNode *y = find_min(node->right);
        if (y->parent != node) {
            delete_helper(&root, y, y->right);
            y->right = node->right;
            y->right->parent = y;
        }
        delete_helper(&root, node, y);
        y->left = node->left;
        y->left->parent = y;
    }



    free(node);
    return root;
}
