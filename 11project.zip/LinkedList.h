
#include <stdbool.h>

// Node structure for the linked list
typedef struct node {
    int key;            
    struct node* next; 
} node;

// create a new node
node* create_node(int key);

//  insert a key into the linked list
bool linked_list_insert(node** head, int key);

// Function to delete
bool linked_list_delete(node** head, int key);

// Function to search for a key
bool linked_list_search(node* head, int key);

// Function to delete all nodes
void linked_list_free(node* head);

