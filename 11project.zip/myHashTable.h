/* myHashTable.h - Header file for hash table; do not modify */

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "LinkedList.h"

// Structure for the hash table
typedef struct HashTable {
    node** values; // Array of pointers to linked lists (for chaining)
    int size;      // Number of buckets in the hash table
    int count;     // Current number of elements in the hash table
} HashTable;

// Function to create a hash table with a specified maximum capacity
HashTable* create_table(int max_capacity);

// Function to insert a key into the hash table
bool insert_key(HashTable *htable, int key);

// Function to delete a key from the hash table

bool delete_key(HashTable *htable, int key);

// Function to search for a key in the hash table
bool search(HashTable *htable, int key);

// Function to clear the hash table and free all allocated memory
void clear_table(HashTable *htable);
