/* jambani.c - Main program to handle hash table and BST operations */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "myHashTable.h"
#include "myBST.h"

#define K 5 // taking k = 5 as asked in the question

// Functions 

int get_predecessors(TreeNode *node, int k, int *predecessors) {
    int count = 0;
    TreeNode *current = node;
    for (int i = 0; i < k; i++) {
        current = find_predecessor(current);
        if (current == NULL) {
            break;
        }
        predecessors[count++] = current->key;
    }
    return count;
}

int get_successors(TreeNode *node, int k, int *successors) {
    int count = 0;
    TreeNode *current = node;
    for (int i = 0; i < k; i++) {
        current = find_successor(current);
        if (current == NULL) {
            break;
        }
        successors[count++] = current->key;
    }
    return count;
}

// commparator function for sorting numbrs in ascending order
int compare_ints(const void *a, const void *b) {
    int int_a = *(const int*)a;
    int int_b = *(const int*)b;
    if(int_a > int_b) return 1;
    if(int_a < int_b) return -1;
    else return 0;
}

// string to integer
int custom_atoi(const char *str) {
    int result = 0;
    int i = 0;
    int sign = 1;

    if (str[i] == '-') {
        sign = -1;
        i++;
    }

    while (str[i] != '\0') {
        if (str[i] >= '0' && str[i] <= '9') {
            result = result * 10 + (str[i] - '0');
        } else {
            break;
        }
        i++;
    }

    return sign * result;
}


int main() {
    int hash_table_size = 10007;
    HashTable* htable = create_table(hash_table_size);
    TreeNode* root = NULL;

    char line[100];
    while (fgets(line, sizeof(line), stdin)) { // reads a line of text from input 
        if (strcmp(line, "K") == 0) { // check two strings if they are same or not comaparision
            break;
        }

        char *comma = strchr(line, ','); // finds the occurence of the comma or character

        // seprating ID and operation
        *comma = '\0'; // where there is comma replave it with newline char
        char *id_str = line;
        char op = *(comma + 1);

        // convert ID part to an integer
        int id = custom_atoi(id_str);

// op means operation which is to be done
        if (op == 'I') {
            bool inserted = insert_key(htable, id);
            if (inserted) {
                TreeNode *new_node = create_tree_node(id);
                if (root == NULL) {
                    root = new_node;
                } else {
                    insert(root, new_node);
                }
            }
        } else if (op == 'D') {
            // Delete operation
            bool deleted = delete_key(htable, id);
            if (deleted) {
                TreeNode *node = find_key(root, id);
                if (node != NULL) {
                    root = delete_node(root, node);
                }
            }
        } else if (op == 'C') {
            // Complaint operation
            bool exists=search(htable, id);
            if (exists) {
                printf("-------------\n");
                printf("Y\n"); // ID exists in the database

                TreeNode *node = find_key(root, id);
                if (node == NULL) {
                    printf("\n");
                    continue;
                }

                // Retrieve up to K predecessors and K successors
                int predecessors[K];
                int pred_count = get_predecessors(node, K, predecessors);

                int successors[K];
                int succ_count = get_successors(node, K, successors);

                int total_neighbors = pred_count + succ_count;
                if (total_neighbors == 0) {
                    printf("\n");
                    continue;
                }

                int *neighbors = (int*)malloc(sizeof(int) * total_neighbors);


                // combineing predecessors and successors
                for (int i = 0; i < pred_count; i++) {
                    neighbors[i] = predecessors[i];
                }
                for (int i = 0; i < succ_count; i++) {
                    neighbors[pred_count + i] = successors[i];
                }

                qsort(neighbors, total_neighbors, sizeof(int), compare_ints); //For the Sort neighbors in an ascending order

                for (int i = 0; i < total_neighbors; i++) {
                    if (i > 0) {
                        printf(",");
                    }
                    printf("%d", neighbors[i]);
                }
                printf("\n-------------");
                printf("\n");

                free(neighbors);
            } else {
                printf("-------------\n");
                printf("N\n");
                printf("-------------\n");
            }
        }
    }

    return 0;
}
