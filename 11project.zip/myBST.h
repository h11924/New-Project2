#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

typedef struct TreeNode {
    int key;                     
    struct TreeNode *left;       
    struct TreeNode *right;      
    struct TreeNode *parent;     
} TreeNode;

//  createing a new TreeNode
TreeNode* create_tree_node(int key);

// Function inserttion to  a node into the BST
void insert(TreeNode *root, TreeNode *node);

// Function to delete a node from the BST
TreeNode* delete_node(TreeNode *root, TreeNode *node);

//  find the successor
TreeNode* find_successor(TreeNode *node);

//  find the predecessor
TreeNode* find_predecessor(TreeNode *node);

// find a node with a specific key in the BST
TreeNode* find_key(TreeNode *root, int key);

// find the minimum node in the subtree rooted at 'node'
TreeNode* find_min(TreeNode *node);

//  find the maximum node in the subtree rooted at 'node'
TreeNode* find_max(TreeNode *node);

