#include "LinkedList.h"
#include <stdlib.h>

//craeting a node 
node* create_node(int key) {
    node* new_node = (node*)malloc(sizeof(node));
    if (!new_node) {
        return NULL; 
    }
    //craeting the node 
    new_node->key = key;
    new_node->next = NULL;

    
    return new_node;
}

// Insert a key 
bool linked_list_insert(node** head, int key) {
    
    node* current = *head;
    while (current) {
        if (current->key == key) {
            return false; // Key already exists
        }
        current = current->next;
    }

    //creating a new node and entering the key in it 
    node* new_node = create_node(key);
    new_node->next = *head;
    *head = new_node;
    return true;
}

// Delete a key 
bool linked_list_delete(node** head, int key) {
    node* current = *head;//initalising variables for traveling 
    node* prev = NULL;

    while (current) {
        if (current->key == key) {
            if (prev) {
                prev->next = current->next;
            } else {
                *head = current->next;
            }
            free(current);
            return true;
        }

        prev = current;
        current = current->next;
    }
    
    return false; // return false if key not found
}

// Search for a key
bool linked_list_search(node* head, int key) {
    node* current = head;
    while (current) {
        if (current->key == key) {
            return true; // return true if key found
        }
        current = current->next;
    }

    return false; // Key not found
}

//deleting the node 
void linked_list_free(node* head) {
    node* current = head;


    while (current) {
        node* temp = current;
        current = current->next;
        free(temp);
    }
}
