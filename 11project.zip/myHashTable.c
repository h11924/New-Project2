#include "myHashTable.h"

//hash function for finding a index to store it
int hash_function(HashTable *htable, int key) {
    if (htable->size == 0) return 0;
    int hash = key % htable->size;//dividing the valye of the key with the size of the table 
    if (hash < 0) hash += htable->size;
    return hash;
}

// Create a hash table with the specified maximum capacity
HashTable* create_table(int max_capacity) {
    HashTable* htable = (HashTable*)malloc(sizeof(HashTable));//allocating memory
    htable->size = max_capacity;//defining size
    htable->count = 0;
    htable->values = (node**)malloc(sizeof(node*) * htable->size);

    //Initialize all to NULL
    for (int i = 0; i < htable->size; i++) {
        htable->values[i] = NULL;
    }
    return htable;
}

//insertig akey in table 
bool insert_key(HashTable *htable, int key) {
    if (!htable) return false;

    int hash = hash_function(htable, key);
    //inserting in linked list
    bool inserted = linked_list_insert(&(htable->values[hash]), key);
    if (inserted) {
        htable->count++;
    }
    return inserted;
}

// Deleting a key 
bool delete_key(HashTable *htable, int key) {
    if (!htable) return false;

    int hash = hash_function(htable, key);
    bool deleted = linked_list_delete(&(htable->values[hash]), key);
    if (deleted) {
        htable->count--;
    }
    return deleted;
}

// Search for a key
bool search(HashTable *htable, int key) {
    if (!htable) return false;

    int hash = hash_function(htable, key);
    return linked_list_search(htable->values[hash], key);
}

//clearing the hash table 
void clear_table(HashTable *htable) {
    if (!htable) return;

    for (int i = 0; i < htable->size; i++) {
        if (htable->values[i] != NULL) {
            linked_list_free(htable->values[i]);
            htable->values[i] = NULL;
        }
    }




    
    free(htable->values);
    free(htable);
}
